
public class Employee {

    private int id;
    private String name;
    public Employee("");
    {
        
    }
}